package com.TaskManager.enums;

public enum UserRole {
    ADMIN, EMPLOYEE
}
