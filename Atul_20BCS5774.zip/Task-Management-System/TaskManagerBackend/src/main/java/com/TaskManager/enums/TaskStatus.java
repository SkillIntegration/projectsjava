package com.TaskManager.enums;

public enum TaskStatus {
    PENDING,
    INPROGRESS,
    COMPLETED,
    DEFERRED,
    CANCELED
}
