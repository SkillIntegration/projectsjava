export class User {
  id: number;
  username: string;
  password: string;
  name: string;
  gender: string;
  dob: string;
  type: string;
}
