export class Prescription {
  patientId: number;
  doctorId: number;
  medicine: string;
  dosage: string;
  medicineId: number;
  description: string;
}
