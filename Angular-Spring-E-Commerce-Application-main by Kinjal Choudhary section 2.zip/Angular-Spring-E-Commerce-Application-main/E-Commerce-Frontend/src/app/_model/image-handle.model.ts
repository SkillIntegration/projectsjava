import { SafeUrl } from "@angular/platform-browser";

export interface ImageHandle{
    image_file: File,
    url: SafeUrl
}