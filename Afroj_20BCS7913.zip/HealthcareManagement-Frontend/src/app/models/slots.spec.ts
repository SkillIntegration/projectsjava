import { Slots } from './slots';

describe('Slots', () => {
  it('should create an instance', () => {
    expect(new Slots()).toBeTruthy();
  });
});
