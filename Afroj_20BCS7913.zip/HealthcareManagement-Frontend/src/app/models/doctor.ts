export class Doctor 
{

    doctorname : string = '';
    email : string = '';
    gender : string = '';
    mobile : String = '';
    experience : string = '';
    address : string = '';
    specialization : string = '';
    previoushospital : string = '';
    password : string = '';
    status : string = 'false';

    constructor() {}
}
