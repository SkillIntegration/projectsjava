export class Slots 
{
    doctorname : string = '';
    email : string = '';
    specialization : string = '';
    date : string = '';
    amslot : string = 'empty';
    amstatus : string = 'unbooked';
    noonslot : string = 'empty';
    noonstatus : string = 'unbooked';
    pmslot : string = 'empty';
    pmstatus : string = 'unbooked';
    patienttype : string = '';

    constructor() {}
}
