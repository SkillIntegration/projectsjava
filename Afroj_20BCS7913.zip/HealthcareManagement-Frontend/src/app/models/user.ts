export class User 
{

    username : string = '';
    email : string = '';
    gender : string = '';
    mobile : string = '';
    age : string = '';
    address : string = '';
    password : string = '';

    constructor() {}
}
