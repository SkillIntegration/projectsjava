export class Prescription
{
    patientid : string = '';
    patientname : string = '';
    doctorname : string = '';
    disease : string = '';
    gender : string = '';
    age : string = '';
    date : string = '';
    prescription : string = '';
    admissionstatus : string = 'false';
}
