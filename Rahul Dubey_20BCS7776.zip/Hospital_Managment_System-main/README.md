E-healthcare management project 
